package taller07;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TransportCompanyTest {
    private TransportCompany company;

    @BeforeEach
    void setup() {
        Truck camion1 = new Truck("BAC216", 150, 85, 0);
        Truck camion2 = new Truck("CAP384", 190, 70, 0);
        Truck camion3 = new Truck("GER270", 280, 100, 0);
        Truck camion4 = new Truck("JKV231", 215, 110, 0);

        company = new TransportCompany(camion1, camion2, camion3, camion4);
    }

    @Test
    void getTruck() {
        assertNull(company.getTruck("ABC123"));

        assertEquals(150, company.getTruck("BAC216").getCapacity());
        assertEquals(190, company.getTruck("CAP384").getCapacity());
        assertEquals(280, company.getTruck("GER270").getCapacity());
        assertEquals(215, company.getTruck("JKV231").getCapacity());

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void loadTruck() {
        assertFalse(company.loadTruck("ABC123", 100));

        assertTrue(company.loadTruck("BAC216", 120));
        assertEquals(120, company.getTruck1().getCurrentLoad());

        assertFalse(company.loadTruck("CAP384", 200));
        assertEquals(0, company.getTruck2().getCurrentLoad());
        assertEquals(190, company.getTruck2().getCapacity());

        assertTrue(company.loadTruck("CAP384", 100));
        assertEquals(190, company.getTruck2().getCapacity());
        assertEquals(100, company.getTruck2().getCurrentLoad());

        assertFalse(company.loadTruck("GER270", 400));
        assertEquals(0, company.getTruck3().getCurrentLoad());
        assertEquals(280, company.getTruck3().getCapacity());

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void unloadTruck() {
        company.unloadTruck("BAC216");
        assertEquals(0, company.getTruck1().getCurrentLoad());

        Truck truck = new Truck("GOB789", 250, 125, 100);
        company = new TransportCompany(truck, truck, truck, truck);

        assertEquals(100, company.getTruck1().getCurrentLoad());
        assertEquals(250, company.getTruck1().getCapacity());

        company.unloadTruck("GOB789");
        assertEquals(0, truck.getCurrentLoad());
        assertEquals(250, truck.getCapacity());

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void getTotalCapacity() {
        assertEquals(835, company.getTotalCapacity());

        Truck truck = new Truck("GOB789", 250, 125, 100);
        company = new TransportCompany(truck, truck, truck, truck);
        assertEquals(1_000, company.getTotalCapacity());

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void getTotalFreight() {
        assertEquals(0, company.getTotalFreight());

        Truck truck = new Truck("GOB789", 250, 125, 100);
        company = new TransportCompany(truck, truck, truck, truck);
        assertEquals(400, company.getTotalFreight());

        Truck camion2 = new Truck("XYZ000", 120, 80, 24);
        company = new TransportCompany(truck, camion2, truck, camion2);
        assertEquals(248, company.getTotalFreight());

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void getAverageLoad() {
        assertEquals(0.0, company.getAverageLoad(), 0.01);

        Truck truck = new Truck("GOB789", 250, 125, 100);
        company = new TransportCompany(truck, truck, truck, truck);
        assertEquals(100.0, company.getAverageLoad(), 0.01);

        Truck camion2 = new Truck("XYZ000", 120, 80, 24);
        company = new TransportCompany(truck, camion2, truck, camion2);
        assertEquals(62.0, company.getAverageLoad(), 0.01);

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void getBestTruck() {
        assertEquals("CAP384", company.getBestTruck(150).getPlate());
        assertEquals("CAP384", company.getBestTruck(175).getPlate());
        assertEquals("GER270", company.getBestTruck(200).getPlate());
        assertEquals("GER270", company.getBestTruck(250).getPlate());
        assertNull(company.getBestTruck(300));

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void trucksWithBreakAndPlate() {
        assertEquals(3, company.trucksWithBreakAndPlate(1));
        assertEquals(1, company.trucksWithBreakAndPlate(2));
        assertEquals(1, company.trucksWithBreakAndPlate(10));
        System.out.println("Prueba superada 👍🏼");
    }
}