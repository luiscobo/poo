/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad Ean (Bogotá - Colombia)
 * Programa de Ingeniería de Sistemas
 * <p>
 * Taller 07 - Objetos compuestos en Java
 * Ejercicio: compañía de transporte
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

package taller07;

/**
 * Un camión de la compañía de transporte
 */
public class Truck {

    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * La placa del camión
     */
    private String plate;

    /**
     * La capacidad del camión (En Kg.)
     */
    private int capacity;

    /**
     * El consumo de gasolina del camión (En galones/kilometro).
     */
    private double gasolineConsumption;

    /**
     * La carga actual del camión (En Kg.)
     */
    private int currentLoad;

    // -----------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------

    /**
     * Creamos un nuevo camión con la placa, capacidad, consumo y carga actual.
     */
    public Truck(String plate, int capacity, double gasolineConsumption, int currentLoad) {
        this.plate = plate;
        this.capacity = capacity;
        this.gasolineConsumption = gasolineConsumption;
        this.currentLoad = currentLoad;
    }

    // -----------------------------------------------------------------
    // Métodos
    // -----------------------------------------------------------------

    /**
     * Obtener la placa del camión
     */
    public String getPlate() {
        return plate;
    }

    /**
     * Obtener la capacidad del camión
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * Obtener los galones de gasolina que consumen los camiones por kilómetro.
     */
    public double getGasolineConsumption() {
        return gasolineConsumption;
    }

    /**
     * Obtener la carga actual del camión
     */
    public int getCurrentLoad() {
        return currentLoad;
    }

    /**
     * Carga un nuevo paquete dentro del camión. Eso se hace a partir de lo sgte:
     * Si el peso del paquete es inferior o igual a la capacidad del camión,
     *      Asígnele a la carga actual del camión el peso del paquete
     *      Retorne true
     * Sino,
     *      Retorne false, indicando que no fue posible cargar el paquete
     * @param packageWeight el peso del paquete
     * @return true si fue posible cargar el paquete, y false en caso contrario
     */
    public boolean load(int packageWeight) {
        // TODO: write your code here
        return false;
    }

    /**
     * Descargar el camión.
     * Lo único que hay que hacer es colocar la carga actual del camión en cero
     */
    public void unload() {
        // TODO: write your code here
    }

    /**
     * Retorna el último caracter de la placa del camión
     */
    public char getPlateLastDigit() {
        // TODO: write your code here
        return ' ';
    }

    /**
     * Permite saber si el camión tiene pico y placa el día que se recibe
     * como parámetro. Devuelve true si tiene, false en caso contrario.
     * De acuerdo con la Alcaldía de Bogotá,
     * Si el día es par
     *      si la placa del camión termina en 1, 2, 3, 4 o 5,
     *      debe retornarse true (tiene pico y placa); en caso contrario,
     *      debe retornarse false (no tiene pico y placa).
     * En caso contrario,
     *      si la placa del camión termina en 6, 7, 8, 9 o 0,
     *      debe retornarse true (tiene pico y placa); en caso contrario,
     *      debe retornarse false (no tiene pico y placa).
     *
     * @param day Un número entero indicando un día del mes
     * @return true si el camión tiene pico y placa y false en caso contrario.
     */
    public boolean hasBreakAndPlate(int day) {
        // TODO: write your code here
        return false;
    }
}
