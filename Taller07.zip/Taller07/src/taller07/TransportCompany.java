/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad Ean (Bogotá - Colombia)
 * Programa de Ingeniería de Sistemas
 * <p>
 * Taller 07 - Objetos compuestos en Java
 * Ejercicio: compañía de transporte
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
package taller07;

/**
 * La compañía de transporte
 */
public class TransportCompany {
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * El primer camión de la compañía
     */
    private Truck truck1;

    /**
     * El segundo camión de la compañía
     */
    private Truck truck2;

    /**
     * El tercer camión de la compañía
     */
    private Truck truck3;

    /**
     * El cuarto camión de la compañía
     */
    private Truck truck4;

    // -----------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------

    /**
     * Esta operación crea una nueva compañía de transporte con cuatro camiones
     */
    public TransportCompany(Truck truck1, Truck truck2, Truck truck3, Truck truck4) {
        this.truck1 = truck1;
        this.truck2 = truck2;
        this.truck3 = truck3;
        this.truck4 = truck4;
    }

    // -----------------------------------------------------------------
    // Métodos
    // -----------------------------------------------------------------


    /**
     * @return el primer camión
     */
    public Truck getTruck1() {
        return truck1;
    }

    /**
     * @return el segundo camión
     */
    public Truck getTruck2() {
        return truck2;
    }

    /**
     * @return el tercer camión
     */
    public Truck getTruck3() {
        return truck3;
    }

    /**
     * @return el cuarto camión
     */
    public Truck getTruck4() {
        return truck4;
    }

    /**
     * Obtiene el camión que tiene la placa (plate)
     * pasada como parámetro. El método debe devolver null
     * si la placa no corresponde a ningún camión.
     */
    public Truck getTruck(String plate) {
        // TODO: write your code here
        return null;
    }

    /**
     * Carga en el camión con la placa dada (plate) un paquete con el peso dado (weight)
     * como parámetro.
     * @return true si la carga fue exitosa, false en caso contrario.
     */
    public boolean loadTruck(String plate, int weight) {
        // TODO: write your code here
        return false;
    }

    /**
     * Descarga el camión que tiene la placa dada (plate)
     */
    public void unloadTruck(String plate) {
        // TODO: write your code here

    }

    /**
     * @return la suma total de las capacidades de todos los camiones de la
     * compañía. No se pueden usar listas ni arreglos ni for ni while ni streams.
     */
    public int getTotalCapacity() {
        // TODO: write your code here
        return 0;
    }

    /**
     * @return la suma de la carga actual de todos los camiones de la compañía
     */
    public int getTotalFreight() {
        // TODO: write your code here
        return 0;
    }

    /**
     * Obtiene el promedio de la carga actual de los 4 camiones.
     */
    public double getAverageLoad() {
        // TODO: write your code here
        return 0.0;
    }

    /**
     * Retorna el mejor camión para transportar el paquete que tiene el peso
     * packageWeight recibido como parámetro. El camión que se debe retornar
     * es el que tenga una capacidad superior o igual a la del peso del paquete y
     * además tenga el consumo de gasolina más bajo. Retorna null si no hay
     * camión que pueda transportar el paquete.
     * @return el mejor camión para transportar el paquete o null
     */
    public Truck getBestTruck(int packageWeight) {
        Truck theBest = null;
        // TODO: write your code here
        return theBest;
    }

    /**
     * Este método retorna la cantidad de camiones que tienen pico y placa
     * el día que se recibe como parámetro. No se pueden usar listas.
     */
    public int trucksWithBreakAndPlate(int day) {
        int cont = 0;
        // TODO: write your code here
        return cont;
    }
}
