package taller07;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TruckTest {
    private Truck camion1, camion2, camion3, camion4;

    @BeforeEach
    void setUp() {
        camion1 = new Truck("BAC216", 150, 85, 0);
        camion2 = new Truck("CAP384", 190, 70, 0);
        camion3 = new Truck("GER270", 280, 100, 0);
        camion4 = new Truck("JKV231", 215, 110, 0);
    }

    @Test
    void loadTest() {
        assertTrue(camion1.load(120));
        assertEquals(120, camion1.getCurrentLoad());

        assertFalse(camion2.load(200));
        assertEquals(0, camion2.getCurrentLoad());
        assertEquals(190, camion2.getCapacity());

        assertTrue(camion2.load(100));
        assertEquals(190, camion2.getCapacity());
        assertEquals(100, camion2.getCurrentLoad());

        assertFalse(camion3.load(400));
        assertEquals(0, camion3.getCurrentLoad());
        assertEquals(280, camion3.getCapacity());

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void unloadTest() {
        camion1.unload();
        assertEquals(0, camion1.getCurrentLoad());

        Truck truck = new Truck("GOB789", 250, 125, 100);
        assertEquals(100, truck.getCurrentLoad());
        assertEquals(250, truck.getCapacity());

        truck.unload();
        assertEquals(0, truck.getCurrentLoad());
        assertEquals(250, truck.getCapacity());

        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void getPlateLastDigitTest() {
        assertEquals('6', camion1.getPlateLastDigit());
        assertEquals('4', camion2.getPlateLastDigit());
        assertEquals('0', camion3.getPlateLastDigit());
        assertEquals('1', camion4.getPlateLastDigit());
        System.out.println("Prueba superada 👍🏼");
    }

    @Test
    void picoYPlaca() {
        assertTrue(camion1.hasBreakAndPlate(21));
        assertFalse(camion1.hasBreakAndPlate(20));
        assertFalse(camion1.hasBreakAndPlate(30));
        assertTrue(camion1.hasBreakAndPlate(27));

        assertTrue(camion3.hasBreakAndPlate(15));
        assertFalse(camion3.hasBreakAndPlate(22));
        assertFalse(camion3.hasBreakAndPlate(28));
        assertTrue(camion3.hasBreakAndPlate(11));

        assertTrue(camion2.hasBreakAndPlate(14));
        assertFalse(camion2.hasBreakAndPlate(21));
        assertFalse(camion2.hasBreakAndPlate(31));
        assertTrue(camion2.hasBreakAndPlate(12));

        System.out.println("Prueba superada 👍🏼");
    }
}